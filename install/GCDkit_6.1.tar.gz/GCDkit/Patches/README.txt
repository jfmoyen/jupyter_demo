Ahoj,

posilam kod pro zaplaty. Melo by to fungovat tak, ze


1. zavolas .buildPatch(c("Jensen","loadData")) ap, jako druhy parametr muzes mit cislo patche, jinak je podle aktualniho data. about() se aktualizuje automaticky


2. v adresari Patch se vytvori soubor installPatchXXXXXX.r


3. ten muzes sourcovat a v adresari Patch ti to udela vlastni zaplatu


4. .loadPatch by se mel volat na konci startu systemu, nacte posledni patch z adresare (podle cisla) a vsechny ne-patch soubory

5.  Pro pozdejsi kompilaci, presun vygenrovany patch do adrase inst/Patch 


Jeste jsem se docela zapotil, proto to zpozdeni. Taky jsem to zkousel pres historii, ale vzdal jsem to.


Jestli to nebude fungovat, tak pokracovani v pondeli. Ted se jeste podivam na ty ostatni veci.


V2