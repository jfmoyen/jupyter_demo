#############################################################################
#                 General function for plotting profiles                    #
#                                                                           #
#############################################################################

profiler<-function(x=NULL,y=NULL,data=WR,method="Variable",legend=FALSE,pch=1,col.lines="black",col="black",cex=1,xaxs="r",yaxs="i",main="",xmin=NULL,xmax=NULL,...){   
    on.exit(options("show.error.messages"=TRUE))
    # This is not a call from a command line, as no x axes are specified
    GUI<-is.null(y)
    
    # Select the samples to be plotted
    if(GUI){
        y1<-selectSubset(where=cbind(labels,data),save=FALSE,GUI=TRUE)
    }else{
        y1<-rownames(data)
    }
    
    if(is.null(y)){
        # Select the variables for y axis
        y<-selectColumnsLabels(message="Select variable(s) to be ploted as individual profiles",exact.only=FALSE)
    } 
  
    # Select method if not specified in the call 
    profile.list<-c("Variable","Equidistant","From-To")
    if(!is.null(x))method<-"Variable"
    if(GUI|is.null(method)){
        which.x<-select.list(profile.list,title="What should be plotted as x axis?",preselect="Selected variable")
        if(nchar(which.x)==0){cat("Cancelled.\n");return()} 
    }else{
        which.x<-method
    }
    pick<-which(profile.list==which.x)
    if(length(pick)==0) {winDialog("ok",paste("Invalid method",which.x,"!"));options("show.error.messages"=FALSE);stop()}
    
    # Get the x data ready, if not specified in the call
    switch(pick,
        # Selected method - Variable
        {
        if(is.null(x)){
            xlab<-selectColumnLabel(where=colnames(data),empty.ok=FALSE,silent=TRUE)
            if(is.null(xlab)){cat("Cancelled.\n");options("show.error.messages"=FALSE);stop()}
            if(!is.na(as.numeric(xlab)))xlab<-colnames(data)[as.numeric(xlab)]
        }else{
            xlab<-x
        }
        
        if(any(colnames(data)==xlab)){
            B<-data[,xlab]
        }else{
            ee<-calcCore(xlab,where = "data")
            B<-ee$results
            xlab<-ee$equation
        }
        B<-B[y1]
        B<-sort(B)
        
        # Set the range to the x axis
        if(is.null(xmin)) xmin<-min(B,na.rm=TRUE)
        if(is.null(xmax)) xmax<-max(B,na.rm=TRUE)
       
        if(GUI){
                xx<-winDialogString("Enter min and max for x-axis, separated by commas",paste(xmin,xmax,sep=","))
                    if(is.null(xx)){cat("Cancelled.\n");options("show.error.messages"=FALSE);stop()}
                ee1<-unlist(strsplit(xx,","))
                    if(length(ee1)<=1) {winDialog("ok","Invalid limits!");options("show.error.messages"=FALSE);stop()}
                xmin<-as.numeric(ee1[[1]])
                xmax<-as.numeric(ee1[[2]])
                if(xmin<0 | xmax<0 | xmin>=xmax) {winDialog("ok","Invalid limits!");options("show.error.messages"=FALSE);stop()}
        }
        x<-xlab
        ee1<- pretty(c(xmin,xmax))
        lbs<-ee1
        xlab<-annotate(xlab)
        },
        # Equidistant/unlabelled
        {
            B<-1:length(y1)
            names(B)<-y1
            ee1<-B            
            lbs<-rep("",length(B))
            xlab<-paste("n = ", max(B),sep="")
            x<-"Equidistant"
        },
        {
        # Equidistant/From-To
            # Set the range to the x axis
            if(is.null(xmin)) xmin<-0
            if(is.null(xmax)) xmax<-1
            ee1<- pretty(c(xmin,xmax))
            if(is.null(x)&GUI){
                xx<-winDialogString("Enter min and max for x-axis, separated by commas",paste(0,1,sep=","))
                    if(is.null(xx)){cat("Cancelled.\n");options("show.error.messages"=FALSE);stop()}
                ee1<-unlist(strsplit(xx,","))
                    if(length(ee1)<=1) {winDialog("ok","Invalid limits!");options("show.error.messages"=FALSE);stop()}
                xmin<-as.numeric(ee1[[1]])
                xmax<-as.numeric(ee1[[2]])
                ee1<- pretty(c(xmin,xmax))
            }
            B<-seq(xmin,xmax,length.out=length(y1))
            names(B)<-y1
            
            lbs<-ee1
            xlab<-"distance"
            x<-"From-To"
        }
    )
    
    # Get the y data ready
    temp<-sapply(y[y!=x], function(f) {
        if(any(colnames(data)==f)){
            i<-data[,f]
        }else{
            ee<-calcCore(f,where = "data")
            i<-ee$results
        }
    })
    A<-temp[names(B),]
    
    A[A==0]<-NA
    if(is.vector(A)){
        A<-t(as.matrix(A))
        rownames(A)<-colnames(temp)
        A<-t(A)
    }
    A<-t(A)
    
    # As well as the range to the y axis
    ymin<-min(A,na.rm=TRUE)
    ymax<-max(A,na.rm=TRUE)
    ee2<- pretty(c(ymin,ymax))
    if(is.null(y)){    
        yy<-winDialogString("Enter min and max for y-axis, separated by commas",paste(min(ee2),max(ee2),sep=","))
            if(is.null(yy)){cat("Cancelled.\n");options("show.error.messages"=FALSE);stop()}
        ee2<-unlist(strsplit(yy,","))
            if(length(ee2)<=1) {winDialog("ok","Invalid limits!");options("show.error.messages"=FALSE);stop()}
        ymin<-as.numeric(ee2[[1]])
        ymax<-as.numeric(ee2[[2]])
        if(ymin<0 | ymax<0 | ymin>=ymax) {winDialog("ok","Invalid limits!");options("show.error.messages"=FALSE);stop()}
        ee2<- pretty(c(ymin,ymax))
    }
    
    # Colours for legend
    if(legend){
        if(length(col.lines)>1){
            leg.col<-col.lines
            pt.cex<-0
            leg.lwd<-2
        }else{
            leg.col<-col
            pt.cex<-cex*0.8
            leg.lwd<-1
        }
    }
    
    # Prepare plotting symbols and colours
    if(GUI){
        # Autoassign?
        ee<-.autoassign.pch(what=t(y),edit=TRUE,legend=FALSE)
        col<-ee$col
        pch<-ee$pch  
        
        # Scaling of plotting symbols
        cex<-as.numeric(winDialogString("Scaling factor","1"))
        if(length(cex)==0){cat("Cancelled.\n");return()}
    }
    options(show.error.messages=T)
    # Replicate pch as necessary
    if(length(pch)==1)  pch<-rep(pch,times=ncol(A)*nrow(A))
    if(length(pch)==nrow(A)) pch<-rep(pch,each=ncol(A))
    if(length(pch)==ncol(A)) pch<-rep(pch,times=nrow(A))
    pch<-matrix(pch,nrow=nrow(A),byrow=TRUE)
    dimnames(pch)<-dimnames(A)
   
    # Replicate col as necessary
    if(length(col)==1)  col<-rep(col,times=ncol(A)*nrow(A))
    if(length(col)==nrow(A))col<-rep(col,each=ncol(A))
    if(length(col)==ncol(A))col<-rep(col,times=nrow(A))
    col<-matrix(col,nrow=nrow(A),ncol=ncol(A),byrow=TRUE)
    dimnames(col)<-dimnames(A)
    
    # Replicate col.lines as necessary
    if(length(col.lines)==1)  col.lines<-rep(col.lines,times=ncol(A)*nrow(A))
    
    # PLOT IT!
    windows(width = 8, height = 6.5, pointsize = 12,title=paste("Profile(s) of",paste(rownames(A),collapse=", ")))        
    if(legend){
        par(omd=c(0,1,0,1))
        par(mar=c(6,4,6,11))
    }
    
    xcex<-0.8
    ycex<-0.8
    temp<-list(
        axis1=list("axis",side=1,at=ee1,labels=lbs,cex.lab=0.8,cex.axis=xcex,las=0,hadj=NA,padj=NA,lty="solid"),
        axis2=list("axis",side=2,at=ee2,labels=ee2,cex.lab=0.8,cex.axis=xcex,las=0,hadj=NA,padj=NA,lty="solid")
    ) 
           
    # Lines and points
    sheet<-list(demo=list(fun="plot",call=list(xlim=range(ee1),ylim=range(ee2),xlab=xlab,ylab="",type="n",axes=FALSE,log="",xaxs=xaxs,yaxs=xaxs,bg="white",main=main),template=temp))
    ee<-lapply(1:nrow(A),function(i){ 
        tempy<-A[i,][!is.na(A[i,])]
        tempx<-B[!is.na(A[i,])]
        # points
        eval(parse(text=(paste("sheet$demo$template$points",i,"<<-list(\"points\",x=B,y=A[",i,",],col=col[",i,",],pch=pch[",i,",],cex=cex)",sep=""))))

        # lines
        eval(parse(text=(paste("sheet$demo$template$lines",i,"<<-list(\"lines\",x=tempx,y=tempy,col=col.lines[",i,"],...)",sep=""))))
    })
    
    # Textual labels
    ee<-lapply(1:nrow(A),function(i){   
        uf<-A[i,which(!is.na(A[i,]))]
        at<-uf[length(uf)]
        eval(parse(text=(paste("sheet$demo$template$mtext",i,"<<-list(\"mtext\",text=annotate(rownames(A)[i]),side=4,line=0,at=at,adj=0.5,padj=NA,las=0,col=col.lines[i],cex=1)",sep=""))))
    })
   
    sheet$demo$template$box<-list("box",which="plot",col="black",lwd=1)
    sheet$demo$template$grid<-list("abline",h=ee2,col="gray",lty="dotted")  
    sheet$demo$template$GCDkit$plot.type<-"profile"

    tit<-paste("Profile (",method,") of ",paste(rownames(A),collapse=", "),sep="")
    sheet$demo$template$GCDkit$plot.name<-tit
    
    #sheet$demo$call$new<-TRUE

    # Legend
    if(legend){
        sheet$demo$legend<-list(x="right",inset=c(-0.3,0.0),legend=sapply(rownames(A),annotate),col=leg.col,pch=pch,cex=0.8,pt.cex=pt.cex,lty="solid",bg="transparent",ncol=1,bty=1,xpd=NA,yjust=0.5,title=NULL,lwd=leg.lwd)
    }else{
        par(mar=c(4.5,4.5,2,4.5)) 
    }
    assign("sheet",sheet,.GlobalEnv)
    pp<-figaro(demo,prefix="sheet")
    assign("pp",pp,.GlobalEnv)
    assign("x.data",B,.GlobalEnv)
    assign("y.data",A,.GlobalEnv)
    assign("results",t(A),.GlobalEnv)
    figRedraw()
    #pp$draw(1,1,xlab=xlab,ylab="",cex=cex,main=main,new=FALSE)
    figaroOn()
    invisible(results)
}
