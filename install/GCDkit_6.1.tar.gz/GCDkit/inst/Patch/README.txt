What to do with a GCDkit patch?

    + Download the patch installation file from the GCDkit 
      website (hold ALT when clicking the link to block automatic opening in your browser)
    
    + Start GCDkit
    
    + Drag-and-drop the installGCDpatchXXXXXX.r file from your download folder 
      onto the R-console (the verbose GCDkit window)

If you see the "Installing the file patch XXXXXX.r" message, well, it is done. 


See: http://blog.gcdkit.org/2013/06/about-gcdkit-patches.html