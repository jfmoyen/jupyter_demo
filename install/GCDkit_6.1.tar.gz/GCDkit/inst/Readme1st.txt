###############################
#                             #
#  Welcome to GCDkit for Win  #
#                             #
###############################
Note that recommended systems to run GCDkit are Windows Vista/7/8/10/11, 
complete functionality/stability under earlier Windows versions cannot be guaranteed. 
This programme should also work on Mac OS X (release 10.6 and above) and various 
distributions of Linux (Debian, RedHat, SUSE, Ubuntu). 

=======================
#    Installation     #
=======================

1. Download *appropriate* version of R for Windows 
--------------------------------------------------
o You can download R either from the CRAN site at http://cran.r-project.org/ or visit http://gcdkit.org/.

o Run the executable file and select the required items as well as the target directory for R installation (thereafter referred to as %GCDKIT_RHOME%).

o When prompted, select a Custom installation and SDI (multiple windows) interface.

o IMPORTANT! The current version of GCDkit, 6.1, has been developed in R 4.1.3. The function under a different version of R cannot be guaranteed. 

2. Download GCDkit
------------------
o Download GCDkit from http://www.gcdkit.org and follow the on site instructions matching your
operation system and desired installation type.

3. Install GCDkit (standard installation on Win) 
------------------------------------------------
o IMPORTANT! Gain the Administrator rights.

o Unzip the installer into some convenient temporary folder.

o Run RGUI, 32 bit version (shortcut labelled "R i386"). Drag and drop the file @INSTALL.r onto the R Console window.
Read the initial information screen, accept the license agreement and follow the instructions.

o NOTE that installation path of the system itself, refered to as %GCDKIT_HOME%, cannot be changed. On some systems it is within the R installation tree (\library\GCDkit), on others custom library directory will be created. 

o The rest of the directory structure and (if logged with administrator rights) shortcut will be created automatically.

4. Running
----------
On Windows GUI, simply double click the shortcut on the desktop and R should start 
loading the GCDkit on fly. 

Alternatively, Start R, goto to menu �Packages|Load package� and select �GCDkit�.
Stopping � if question whether you like to save the workspace appears, reply �No�

Last option is to start R and type library(GCDkit) into the R Console 
window. 

The Tcl/Tk (platform-independent) menu system (e.g. Mac, Linux) is started by typing 
menuet() into the R Console.

===========================
#     Troubleshooting     #
===========================

� WARNING: DO NOT DELETE the file '.Rprofile' residing in the main GCDkit directory. Otherwise desktop shortcuts to run the GCDkit will stop working!


* Setup does not start at all or is extremely slow
--------------------------------------------------
This may happen with some resident antivirus programmes. Please switch off the resident protection temporarily. 


* Creating a shortcut to the RGUI.exe on your desktop (if the automatic install fails)
--------------------------------------------------------------------------------------
Specify the main directory, where RGUI.exe resides (%GCDKIT_RHOME%\bin).

It can look something like:
Target: "C:\R\R-4.1.3\bin\i386\Rgui.exe" --silent --no-save --sdi


NB that in the 64-bit version, RODBC library does not function properly and thus the import/export from/to MS Excel, Access and DBF are not available. This also concerns the Mac system, taht are are 64-bit only nowadays.


Starting (Run in) directory: "C:\R\R-4.1.3\library\GCDkit" 
(or such alike, the place where GCDkit library is located)


* Any diagram based on plate concept fails to be drawn (e.g., multiple plots such as Harker plots)
--------------------------------------------------------------------------------------------------
Make sure that R runs in SDI mode, i.e., that each of the plotting windows is independent and can be moved about your desktop freely. 


* The graphic windows fail to redraw, especially if too many of them are being open. 
-------------------------------------------------------------------------------------- 
While working, try to keep the number of open graphical windows to a necessary minimum), as the R may become instable, failing to redraw graphical windows if too many of them are being open. It is always a good idea to close the unnecessary ones, for instance using the function graphicsOff() or the corresponding item from the menu GCDkit.


* Some of the functions/the whole system fail.
-------------------------------------------------------------------------------------- 
Double check the manual and your data. If necessary, report the bug. For doing so, make sure that you send maximum information, i.e. attach your dataset, describe us in length what version of system, R and GCDkit you are using and what exactly happened (or did not happen ;-)). 

Enjoy!

Vojtech Janousek and others

vojtech.janousek@geology.cz
1 July 2022
---------------------------
http://www.gcdkit.org
