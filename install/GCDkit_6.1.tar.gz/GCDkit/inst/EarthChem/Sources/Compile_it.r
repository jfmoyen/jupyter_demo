# Source code to be compiled by:
dir<-paste(Sys.getenv("USERPROFILE"),"/Dropbox/R/GCDkitDevelop/inst/EarthChem",sep="/")
setwd(dir)
require(compiler)
cmpfile("Sources\\common_graphcoord.r", "common_graphcoord_COMPILED.r")
cmpfile("Sources\\common_mytkrplot.r", "common_mytkrplot_COMPILED.r")
cmpfile("Sources\\SelectPgonMap.r", "SelectPgonMap_COMPILED.r")
