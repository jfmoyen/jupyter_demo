.files.only<-function(directory,pattern="*.*",full.names=TRUE){
    ee<-list.files(path=directory,pattern=pattern,full.names=full.names)
    if(is.vector(ee)) return(ee)
    return(ee[!(file.info(ee))[2]])    
}


.replace.in.file<-function(filename,pattern,replacement){
                #browser()
                file.in<-filename
                file.out<-paste(file.in,".tmp",sep="")
                input<-file(file.in,open="r")

                xx<-readLines(input)
                xx<-gsub(pattern,replacement,xx,fixed=TRUE) # Popis klasifikacnich poli
                
                i<-grep("clssf=",xx)
                
                #pattern2<-gsub("\n$","@",tolower(pattern))
                #pattern2<-substr(pattern,1,nchar(pattern)-2)
                pattern2<-gsub("-\\n","",tolower(pattern),fixed=TRUE)
                pattern2<-gsub("\\n"," ",pattern2,fixed=TRUE)
                #pattern2<-gsub("@","",pattern2,fixed=TRUE)
                
                #replacement2<-gsub("\n$","@",tolower(replacement))
                replacement2<-gsub("-\\n","",tolower(replacement),fixed=TRUE)
                replacement2<-gsub("\\n"," ",replacement2,fixed=TRUE)
                #replacement2<-gsub("@","",replacement2,fixed=TRUE)
                
                lapply(i, function(j){                
                    xx[j]<<-gsub(pattern2,replacement2,xx[j],fixed=TRUE) # klasifikace
                })
                
                cat(xx,file=file.out,sep="\n")
                close(input)
                file.remove(file.in)
                file.rename(file.out,file.in)
}

# Copy all 
pathClas<-paste("C:/R/lib/GCDkitDevelop/inst","Diagrams","Classification",sep="/")
langs<- .files.only(pathClas,"*[^.r]$",full.names=FALSE)
langs<-langs[langs!="English"]
lapply(langs,function(lang){
    cat("Language =",toupper(lang),"\n")
    pathTo<-paste(pathClas,lang,sep="/")
    pathFrom<-paste(pathClas,"English",sep="/")
    
    #dir.create(pathTo)
    files<-.files.only(pathFrom,"*.*",full.names=FALSE)
    ee<-file.copy(paste(pathFrom,files,sep="/"), paste(pathTo,files,sep="/"), overwrite = TRUE, recursive = FALSE)

    dict<-paste(pathTo,".dict.txt",sep="/")
    input<-file(dict,open="r")
    xx<-read.table(input,sep="\t")#,encoding = "UTF-8")
    close(input)
    xx<-as.matrix(xx)
    lapply(1:nrow(xx),function(i){
    print(paste(pathTo,"/",xx[i,1],".r",sep=""))
    flush.console()
    source<-xx[i,2]
    replacement<-xx[i,3]
    .replace.in.file(paste(pathTo,"/",xx[i,1],".r",sep=""),source,replacement)
})

})
