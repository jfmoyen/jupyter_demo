#####################################################################
#                                                                   #
#          B - Q - F ternary plot of Debon and Le Fort (1983)       #
#                                                                   #
#####################################################################


DebonBQF<-function(reference.rocks=TRUE){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }
    debon<-DebonCalc(milli)
    
    aa<-debon[,"B(dark m.)"]/100
    bb<-debon[,"Q(quartz)"]/100
    cc<-debon[,"F(feldsp)"]/100
    
    x.data<<-cc+bb/2
    y.data<<-sqrt(3)*bb/2

    temp1<-list(
        lines1=list("lines",x=c(0,1,.5,0),y=c(0,0,sqrt(3)/2,0),col="black"),
        lines2=list("lines",x=c(0.93,0.465),y=c(0,0.8054036),col=plt.col[2],lty="dashed"), 
        lines3=list("lines",x=c(0.9,0.45),y=c(0,0.7794229),col=plt.col[2],lty="dashed"),
        lines4=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("gr","ad","gd","to"),labs=c("","","",""),col="gold4",type="l",just.draw=TRUE),
        A=list("text",x=0.29,y=-0.03,text="B(dark m.)",adj=0),
        B=list("text",x=0.78,y=0.43,text="Q(quartz)",adj=0),
        C=list("text",x=1,y=-0.03,text="F(feldsp)",adj=1),
        GCDkit=list("NULL",plot.type="ternary",plot.position=35.4,plot.name="B-Q-F (Debon + Le Fort 1988)")
    )
    
    temp2<-list(
            text1=list("text",x=0.83,y=0.013,text="MESOCRATIC",col=plt.col[2],cex=0.8,adj=1,srt=-60),
            text2=list("text",x=0.91,y=0.013,text="SUBLEUCOCRATIC",col=plt.col[2],cex=0.8,adj=1,srt=-60),
            text3=list("text",x=0.94,y=0.013,text="LEUCOCRATIC",col=plt.col[2],cex=0.8,adj=1,srt=-60)
    )

    temp3<-list(
            debonIdeal1=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("gr","ad","gd","to","dq","go"),labs=c("gr","ad","gd","to","dq","go"),col="gold4",pch=19,cex=1,type="p",just.draw=TRUE),
            debonIdeal2=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("sq","mzq","mzdq","s","mz","mzgo"),labs = c("sq","mzq","mzdq","s","mz","mzgo"),col="gold4",pch=19,cex=1,type="p",just.draw=TRUE)
    )
    
    if(getOption("gcd.plot.text")){
        temp<-c(temp1,temp2)
    }else{
        temp<-temp1
    }
    
    if(reference.rocks){
        temp<-c(temp,temp3)
    }
    
    temp.tick<-list()
    inter<-seq(0.1,0.9,by=0.1)
    for(i in seq(1,1/0.1-1,by=1)){
        ee<-list(
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+1,"<-list(\"lines\",x=c(",inter[i]/2,",",inter[i]/2+0.030,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+2,"<-list(\"lines\",x=c(",inter[i]/2,",",inter[i]/2+0.015,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2-sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+3,"<-list(\"lines\",x=c(",1-inter[i]+inter[i]/2,",",1-inter[i]+inter[i]/2-0.030,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+4,"<-list(\"lines\",x=c(",1-inter[i]+inter[i]/2,",",1-inter[i]+inter[i]/2-0.015,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2-sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+5,"<-list(\"lines\",x=c(",inter[i],",",inter[i]+0.015,"),y=c(0,",sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+6,"<-list(\"lines\",x=c(",inter[i],",",inter[i]-0.015,"),y=c(0,",sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep="")))
        )
    }

    temp<-c(temp,temp.tick)
    
    sheet<<-list(demo=list(fun="plot",
                       call=list(xlim=c(0.29,1.03),
                                 ylim=c(-0.08,0.35),
                                 #ylim=c(-0.08,1.03),
                                 main=annotate("Debon and Le Fort B-Q-F"),
                                 bg="transparent",
                                 fg="black",
                                 asp=1,
                                 axes=F,
                                 type="p",
                                 xlab="",
                                 ylab=""),
                       template=temp))  
    invisible(debon)
}
