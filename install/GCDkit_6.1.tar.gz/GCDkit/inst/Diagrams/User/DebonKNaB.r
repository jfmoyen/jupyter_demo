#####################################################################
#                                                                   #
#             K/(Na+K) vs. B plot of Debon and Le Fort (1988)       #
#                                                                   #
#####################################################################

DebonKNaB<-function(){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }

    temp1<-list(
        #plot
        lines1=list("lines",x=c(0.5,0.5),y=c(0,500),col=plt.col[2],lty="dashed"),
        lines2=list("lines",x=c(0.45,0.45),y=c(0,500),col=plt.col[2],lty="dashed"),
        lines3=list("lines",x=c(0.8,0),y=c(38.8,38.8),col=plt.col[2],lty="dashed"),
        lines4=list("lines",x=c(0.8,0),y=c(55.5,55.5),col=plt.col[2],lty="dashed"),
        GCDkit=list("NULL",plot.type="binary",plot.position=35.1,plot.name="K/(Na+K)-B (Debon + Le Fort 1988)")
        )
    temp2<-list(
        text1=list("text",x=0.7,y=300,text="POTASSIC\nASSOCIATIONS",col=plt.col[2],srt=90),
        text2=list("text",x=0.475,y=300,text="SODI-POTASSIC ASSOCIATIONS",col=plt.col[2],srt=90),
        text3=list("text",x=0.25,y=300,text="SODIC\nASSOCIATIONS",col=plt.col[2],srt=90),
        text4=list("text",x=0.5,y=47,text="SUBLEUCOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8),
        text5=list("text",x=0.5,y=100,text="MESOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8),
        text6=list("text",x=0.5,y=20,text="LEUCOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8)
    )

    if(getOption("gcd.plot.text")){
        temp<-c(temp1,temp2)
    }else{
        temp<-temp1
    }
    
    debon<-DebonCalc(milli)
    x.data<<-debon[,"K/(Na+K)"]
    y.data<<-debon[,"B"]
    sheet<<-list(demo=list(fun="plot", call=list(xlim=c(0.8,0),ylim=c(0,500),col="green",bg="transparent",fg="black",main=annotate("Debon and Le Fort K/(Na+K)-B"),ylab="B = Fe + Mg + Ti",xlab="K/(Na + K)"),template=temp))
    invisible(debon)
}
