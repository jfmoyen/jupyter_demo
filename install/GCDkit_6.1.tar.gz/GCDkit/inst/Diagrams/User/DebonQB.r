#####################################################################
#                                                                   #
#                   Q vs. B plot of Debon and Le Fort (1988)        #
#                                                                   #
#####################################################################

DebonQB<-function(){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }

    temp1<-list(
        lines1=list("lines",x=c(0,300),y=c(38.8,38.8),col=plt.col[2],lty="dashed"),
        lines2=list("lines",x=c(0,300),y=c(55.5,55.5),col=plt.col[2],lty="dashed"),
        GCDkit=list("NULL",plot.type="binary",plot.position=35.2,plot.name="Q-B (Debon + Le Fort 1988)")
    )
    
    temp2<-list(
        text1=list("text",x=150,y=47,text="SUBLEUCOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8),
        text2=list("text",x=150,y=100,text="MESOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8),
        text3=list("text",x=150,y=20,text="LEUCOCRATIC ASSOCIATIONS",col=plt.col[3],cex=0.8)
    )
    
    if(getOption("gcd.plot.text")){
        temp<-c(temp1,temp2)
    }else{
        temp<-temp1
    }
    
    debon<-DebonCalc(milli)
    x.data<<-debon[,"Q"]
    y.data<<-debon[,"B"]
    sheet<<-list(demo=list(fun="plot", call=list(xlim=c(0,300),ylim=c(0,500),col="green",bg="transparent",fg="black",main=annotate("Debon and Le Fort Q-B"),ylab="B = Fe + Mg + Ti",xlab="Q = Si/3 - (K + Na + 2Ca/3)"),template=temp))
    invisible(debon)
}
