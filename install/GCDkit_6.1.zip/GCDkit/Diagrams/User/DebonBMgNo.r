#####################################################################
#                                                                   #
#               B vs. Mg no plot of Debon and Le Fort (1988)        #
#                                                                   #
#####################################################################

DebonBMgNo<-function(reference.rocks=TRUE){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }
    
    temp1<-list(
        lines1=list("abline",v=38.8,col="black",lty="dashed"),
        lines2=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("gr","ad","gd","to","dq","go"),labs=c("","","","","",""),col="gold4",pch=19,cex=0,type="l",just.draw=TRUE),
        GCDkit=list("NULL",plot.type="binary",plot.position=35.3,plot.name="B-Mg.no (Debon + Le Fort 1988)")
    )
    
    temp2<-list(
        text1=list("text",x=100,y=0.48,text="MAGNESIAN  ASSOCIATIONS",col=plt.col[2],adj=0,srt=20),
        text2=list("text",x=100,y=0.34,text="FERRIFERROUS  ASSOCIATIONS",col=plt.col[2],adj=0,srt=20)
    )
        
    temp3<-list(
            debonIdeal1=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("gr","ad","gd","to","dq","go"),labs=c("gr","ad","gd","to","dq","go"),col="gold4",pch=19,cex=1,type="p",just.draw=TRUE),
            debonIdeal2=list("reservoirs",autoscale=FALSE,var.name="debon.ideal.data",sample.names=c("sq","mzq","mzdq","s","mz","mzgo"),labs = c("sq","mzq","mzdq","s","mz","mzgo"),col="gold4",pch=19,cex=1,type="p",just.draw=TRUE)
    )
    
    if(getOption("gcd.plot.text")){
        temp<-c(temp1,temp2)
    }else{
        temp<-temp1
    }
    
    if(reference.rocks){
        temp<-c(temp,temp3)
    }
    debon<-DebonCalc(milli)
    x.data<<-debon[,"B"]
    y.data<<-debon[,"Mg/(Fe+Mg)"]
    sheet<<-list(demo=list(fun="plot", call=list(xlim=c(0,400),ylim=c(0,0.8),col="green",bg="transparent",fg="black",main=annotate("Debon and Le Fort B-Mg/(Fe+Mg)"),xlab="B = Fe + Mg + Ti",ylab="Mg/(Fe + Mg)"),template=temp))
    invisible(debon)
}
